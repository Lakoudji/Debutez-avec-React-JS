import { plantList } from '../datas/plantList'

function ShoppingList() {
	return <ul></ul>
}

export default ShoppingList
